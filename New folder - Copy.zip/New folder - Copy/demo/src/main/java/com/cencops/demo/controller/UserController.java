package com.cencops.demo.controller;

import com.cencops.demo.dto.request.ChangePasswordRequest;
import com.cencops.demo.dto.request.UserResponse;
import com.cencops.demo.dto.response.ApiResponse;
import com.cencops.demo.entity.User;
import com.cencops.demo.exception.AppExceptionHandler;
import com.cencops.demo.repository.UserRepository;
import com.cencops.demo.service.UserService;
import com.cencops.demo.utils.MessageConstants;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")
@RequiredArgsConstructor
public class UserController {

    private final UserRepository userRepository;
    private final UserService userService;

    @GetMapping("/me")
    public ResponseEntity<UserResponse> getProfile() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();

        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new AppExceptionHandler.UserNotFoundException(MessageConstants.USER_NOT_FOUND));

        return ResponseEntity.ok(userService.getUserById(user.getId()));
    }

    @PreAuthorize("hasAnyRole('ANALYST')")
    @PutMapping("/me/password")
    public ResponseEntity<ApiResponse> changePassword(@RequestBody ChangePasswordRequest request) {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();

        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new AppExceptionHandler.UserNotFoundException(MessageConstants.USER_NOT_FOUND));

        userService.changePassword(user.getId(), request);

        return ResponseEntity.ok(new ApiResponse(MessageConstants.SUCCESS, MessageConstants.PASSWORD_UPDATED));
    }
}
