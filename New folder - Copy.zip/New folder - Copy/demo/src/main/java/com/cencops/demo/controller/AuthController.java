package com.cencops.demo.controller;


import com.cencops.demo.config.security.JwtTokenUtil;
import com.cencops.demo.dto.request.LoginRequest;
import com.cencops.demo.dto.request.RegisterRequest;
import com.cencops.demo.entity.User;
import com.cencops.demo.exception.AppExceptionHandler;
import com.cencops.demo.repository.UserRepository;
import com.cencops.demo.service.UserService;
import com.cencops.demo.utils.MessageConstants;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

import com.cencops.demo.dto.response.ApiResponse;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final JwtTokenUtil jwtTokenUtil;
    private final UserService userService;
    private final UserRepository userRepository;

    @PostMapping("/login")
    public ResponseEntity<?> login(
            @RequestBody LoginRequest request,
            HttpServletResponse response) {

        Authentication authentication =
                authenticationManager.authenticate(
                        new UsernamePasswordAuthenticationToken(
                                request.getUsername(),
                                request.getPassword()));

        String role = authentication.getAuthorities()
                .iterator()
                .next()
                .getAuthority()
                .replace("ROLE_", "");

        String accessToken =
                jwtTokenUtil.generateAccessToken(request.getUsername(), role);

        String refreshToken =
                jwtTokenUtil.generateRefreshToken(request.getUsername());

        ResponseCookie cookie = ResponseCookie.from("refreshToken", refreshToken)
                .httpOnly(true)
                .secure(true)
                .path("/auth")
                .maxAge(7 * 24 * 60 * 60)
                .sameSite("Strict")
                .build();

        response.addHeader(HttpHeaders.SET_COOKIE, cookie.toString());

        return ResponseEntity.ok(Map.of("accessToken", accessToken));
    }

    @PostMapping("/refresh")
    public ResponseEntity<?> refresh(@CookieValue("refreshToken") String refreshToken) {

        if (!jwtTokenUtil.validateToken(refreshToken) ||
                !"REFRESH".equals(jwtTokenUtil.getTokenType(refreshToken))) {
            throw new AppExceptionHandler.CustomException(
                    "Invalid refresh token",
                    org.springframework.http.HttpStatus.UNAUTHORIZED
            );
        }

        String username = jwtTokenUtil.getUsername(refreshToken);

        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new AppExceptionHandler.UserNotFoundException(MessageConstants.USER_NOT_FOUND));

        String newAccessToken =
                jwtTokenUtil.generateAccessToken(username, user.getRole().name());

        return ResponseEntity.ok(Map.of("accessToken", newAccessToken));
    }

    @PostMapping("/logout")
    public ResponseEntity<ApiResponse> logout(HttpServletResponse response) {

        ResponseCookie cookie = ResponseCookie.from("refreshToken", "")
                .httpOnly(true)
                .path("/auth")
                .maxAge(0)
                .build();

        response.addHeader(HttpHeaders.SET_COOKIE, cookie.toString());

        return ResponseEntity.ok(new ApiResponse(MessageConstants.SUCCESS, MessageConstants.LOGOUT_SUCCESS));
    }

//    @PostMapping("/register")
//    @PreAuthorize("hasRole('ADMIN')")
//    public ResponseEntity<ApiResponse> register(@Valid @RequestBody RegisterRequest request) {
//        userService.registerUser(request);
//        return ResponseEntity.status(201)
//                .body(new ApiResponse(MessageConstants.SUCCESS, MessageConstants.USER_CREATED));
//    }
}
