package com.cencops.demo.repository;

import com.cencops.demo.entity.DailyActivity;
import com.cencops.demo.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface DailyActivityRepository extends JpaRepository<DailyActivity, Long> {

    Optional<DailyActivity> findByUserAndActivityDate(User user, LocalDate activityDate);

    List<DailyActivity> findAllByUser(User user);
}
