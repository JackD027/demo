package com.cencops.demo.controller;

import com.cencops.demo.dto.request.AdminChangePasswordRequest;
import com.cencops.demo.dto.request.AdminUpdateUserRequest;
import com.cencops.demo.dto.request.RegisterRequest;
import com.cencops.demo.dto.request.UserResponse;
import com.cencops.demo.dto.response.ApiResponse;
import com.cencops.demo.entity.User;
import com.cencops.demo.exception.AppExceptionHandler;
import com.cencops.demo.repository.UserRepository;
import com.cencops.demo.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import com.cencops.demo.utils.MessageConstants;

@RestController
@RequestMapping("/admin")
@RequiredArgsConstructor
public class AdminController {


    private final UserService userService;
    private final UserRepository userRepository;

    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN','MANAGER')")
    @GetMapping("/users")
    public ResponseEntity<List<UserResponse>> getAllUsers() {
        return ResponseEntity.ok(userService.getAllUsers());
    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN','MANAGER')")
    @GetMapping("/users/{id}")
    public ResponseEntity<UserResponse> getUser(@PathVariable Long id) {
        return ResponseEntity.ok(userService.getUserById(id));
    }


//    @GetMapping("/me")
//    public ResponseEntity<UserResponse> getProfile() {
//        String username = SecurityContextHolder.getContext().getAuthentication().getName();
//        User user = userRepository.findByUsername(username)
//                .orElseThrow(() -> new AppExceptionHandler.UserNotFoundException(MessageConstants.USER_NOT_FOUND));
//
//        return ResponseEntity.ok(userService.getUserById(user.getId()));
//    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN')")
    @PostMapping("/register")
    public ResponseEntity<ApiResponse> register(@RequestBody RegisterRequest request) {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new AppExceptionHandler.UserNotFoundException(MessageConstants.USER_NOT_FOUND));

        userService.registerUser(request,user);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(new ApiResponse(MessageConstants.SUCCESS, MessageConstants.USER_CREATED));
    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN')")
    @PutMapping("/users/{id}")
    public ResponseEntity<ApiResponse> updateUser(
            @PathVariable Long id,
            @RequestBody AdminUpdateUserRequest request) {

        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new AppExceptionHandler.UserNotFoundException(MessageConstants.USER_NOT_FOUND));

        userService.adminUpdateUser(id, request,user);
        return ResponseEntity.ok(new ApiResponse(MessageConstants.SUCCESS, MessageConstants.USER_UPDATED));
    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN')")
    @PutMapping("/users/{id}/status")
    public ResponseEntity<ApiResponse> changeStatus(
            @PathVariable Long id,
            @RequestParam("status") String statusStr) {

        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new AppExceptionHandler.UserNotFoundException(MessageConstants.USER_NOT_FOUND));

        User.Status status;
        try {
            status = User.Status.valueOf(statusStr.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new AppExceptionHandler.CustomException(MessageConstants.INVALID_STATUS, HttpStatus.BAD_REQUEST);
        }

        userService.updateUserStatus(id, status,user);
        return ResponseEntity.ok(new ApiResponse(MessageConstants.SUCCESS, MessageConstants.USER_STATUS_UPDATED + status));
    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN')")
    @PutMapping("/users/{id}/password")
    public ResponseEntity<ApiResponse> updateUserPasswordByAdmin(
            @PathVariable Long id,
            @Valid @RequestBody AdminChangePasswordRequest request) {

        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new AppExceptionHandler.UserNotFoundException(MessageConstants.USER_NOT_FOUND));

        userService.adminChangePassword(id, request.getNewPassword(),user);
        return ResponseEntity.ok(new ApiResponse(MessageConstants.SUCCESS, MessageConstants.PASSWORD_UPDATED));
    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN')")
    @DeleteMapping("/users/{id}")
    public ResponseEntity<ApiResponse> deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
        return ResponseEntity.ok(new ApiResponse(MessageConstants.SUCCESS, MessageConstants.USER_DELETED));
    }
}
