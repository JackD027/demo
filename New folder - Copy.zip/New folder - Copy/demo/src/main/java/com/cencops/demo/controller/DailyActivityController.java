package com.cencops.demo.controller;

import com.cencops.demo.dto.request.DailyActivityRequest;
import com.cencops.demo.dto.response.ApiResponse;
import com.cencops.demo.entity.User;
import com.cencops.demo.exception.AppExceptionHandler;
import com.cencops.demo.repository.UserRepository;
import com.cencops.demo.service.DailyActivityService;
import com.cencops.demo.utils.MessageConstants;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/daily-activities")
@RequiredArgsConstructor
public class DailyActivityController {

    private final DailyActivityService dailyActivityService;
    private final UserRepository userRepository;

    @PreAuthorize("hasRole('ANALYST')")
    @PostMapping
    public ResponseEntity<ApiResponse> createActivity(@RequestBody DailyActivityRequest request) {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new AppExceptionHandler.UserNotFoundException(MessageConstants.USER_NOT_FOUND));
        dailyActivityService.createActivity(user, request);

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(new ApiResponse(MessageConstants.SUCCESS,MessageConstants.ACTIVITY_CREATED ));
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ANALYST','ADMIN')")
    public ResponseEntity<?> getMyActivities() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new AppExceptionHandler.UserNotFoundException(MessageConstants.USER_NOT_FOUND));
        return ResponseEntity.ok(dailyActivityService.getUserActivities(user));
    }

    @GetMapping("/tools")
    @PreAuthorize("hasAnyRole('ANALYST','ADMIN')")
    public ResponseEntity<?> getAllTools() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new AppExceptionHandler.UserNotFoundException(MessageConstants.USER_NOT_FOUND));
        return ResponseEntity.ok(dailyActivityService.getAllTools());
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ANALYST','ADMIN')")
    public ResponseEntity<ApiResponse> updateActivity(
            @PathVariable Long id,
            @RequestBody DailyActivityRequest request) {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new AppExceptionHandler.UserNotFoundException(MessageConstants.USER_NOT_FOUND));
        dailyActivityService.update(id, request,user,User.Role.ADMIN == user.getRole());
        return ResponseEntity.ok(
                new ApiResponse(MessageConstants.SUCCESS, MessageConstants.ACTIVITY_UPDATED)
        );
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('ANALYST','ADMIN')")
    public ResponseEntity<ApiResponse> deleteActivity(
            @PathVariable Long id) {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new AppExceptionHandler.UserNotFoundException(MessageConstants.USER_NOT_FOUND));
        dailyActivityService.deleteActivity(
                id,user,User.Role.ADMIN == user.getRole());

        return ResponseEntity.ok(
                new ApiResponse(MessageConstants.SUCCESS, MessageConstants.ACTIVITY_DELETED)
        );
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/admin/test")
    public String test() {
        return "OK";
    }

}
