package com.cencops.demo.dto.request;

import lombok.Data;

@Data
public class RegisterRequest {
    private String name;
    private String designation;
    private String username;
    private String password;
}
