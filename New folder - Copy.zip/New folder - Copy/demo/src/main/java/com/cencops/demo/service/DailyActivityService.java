package com.cencops.demo.service;

import com.cencops.demo.dto.request.DailyActivityRequest;
import com.cencops.demo.dto.response.DailyActivityResponse;
import com.cencops.demo.entity.DailyActivity;
import com.cencops.demo.entity.Tool;
import com.cencops.demo.entity.User;
import com.cencops.demo.exception.AppExceptionHandler;
import com.cencops.demo.repository.DailyActivityRepository;
import com.cencops.demo.repository.ToolRepository;
import com.cencops.demo.utils.MessageConstants;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;

import java.time.*;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DailyActivityService {

    private final DailyActivityRepository repository;
    private final ToolRepository toolRepository;

    private Instant startOfToday() {
        return LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant();
    }

    private Instant endOfToday() {
        return LocalDate.now().atTime(LocalTime.MAX).atZone(ZoneId.systemDefault()).toInstant();
    }

    private boolean isEodPassed(Instant activityCreatedAt) {
        LocalDate activityDate = activityCreatedAt.atZone(ZoneId.systemDefault()).toLocalDate();
        Instant endOfActivityDay = activityDate.atTime(LocalTime.MAX).atZone(ZoneId.systemDefault()).toInstant();
        return Instant.now().isAfter(endOfActivityDay);
    }

    // Convert tool names to IDs, creating tools if they do not exist
    private List<Long> resolveToolIds(List<String> toolNames) {
        if (toolNames == null) return List.of();
        return toolNames.stream()
                .map(name -> toolRepository.findByNameIgnoreCase(name)
                        .orElseGet(() -> toolRepository.save(Tool.builder().name(name).build()))
                        .getId())
                .collect(Collectors.toList());
    }

    public void createActivity(User user, DailyActivityRequest request) {
        repository.findByUserAndActivityDate(user, request.getActivityDate())
                .ifPresent(a -> {
                    throw new AppExceptionHandler.CustomException(MessageConstants.ACTIVITY_ALREADY_PRESENT,HttpStatus.CONFLICT);
                });

        DailyActivity activity = DailyActivity.builder()
                .user(user)
                .activityDate(request.getActivityDate() != null ? request.getActivityDate() : LocalDate.now())
                .detailOfCase(request.getDetailOfCase())
                .typeOfInformation(request.getTypeOfInformation())
                .nameOfIO(request.getNameOfIO())
                .status(DailyActivity.ActivityStatus.valueOf(request.getStatus()))
                .remarks(request.getRemarks())
                .build();
        activity.setToolsUsedIds(resolveToolIds(request.getToolsUsed()));
        activity.setMiscellaneousWorkList(request.getMiscellaneousWork());

        repository.save(activity);
    }

    public List<DailyActivityResponse> getUserActivities(User user) {
        return (user.getRole() == User.Role.ADMIN
                ? repository.findAll()
                : repository.findAllByUser(user))
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public List<Tool> getAllTools(){
        return toolRepository.findAll();
    }

    public void update(Long id, DailyActivityRequest request, User user, boolean isAdmin) {
        DailyActivity activity = repository.findById(id)
                .orElseThrow(() -> new AppExceptionHandler.ResourceNotFoundException(
                        MessageConstants.ACTIVITY_NOT_FOUND
                ));

        if (!isAdmin) {
            if (!activity.getUser().getId().equals(user.getId())) {
                throw new AccessDeniedException(MessageConstants.UNAUTHORIZED);
            }
            if (isEodPassed(activity.getCreatedAt())) {
                throw new AppExceptionHandler.CustomException(
                        MessageConstants.EDIT_AFTER_DAY_END,
                        HttpStatus.FORBIDDEN
                );
            }
        }

        activity.setActivityDate(request.getActivityDate());
        activity.setDetailOfCase(request.getDetailOfCase());
        activity.setTypeOfInformation(request.getTypeOfInformation());
        activity.setNameOfIO(request.getNameOfIO());
        activity.setToolsUsedIds(resolveToolIds(request.getToolsUsed()));
        activity.setMiscellaneousWorkList(request.getMiscellaneousWork());
        activity.setStatus(DailyActivity.ActivityStatus.valueOf(request.getStatus()));
        activity.setRemarks(request.getRemarks());

        repository.save(activity);
    }

    public void deleteActivity(Long id, User user, boolean isAdmin) {
        DailyActivity activity = repository.findById(id)
                .orElseThrow(() -> new AppExceptionHandler.ResourceNotFoundException(
                        MessageConstants.ACTIVITY_NOT_FOUND
                ));

        if (!isAdmin) {
            if (!activity.getUser().getId().equals(user.getId())) {
                throw new AccessDeniedException(MessageConstants.UNAUTHORIZED);
            }
            if (isEodPassed(activity.getCreatedAt())) {
                throw new AppExceptionHandler.CustomException(
                        MessageConstants.DELETE_AFTER_DAY_END,
                        HttpStatus.FORBIDDEN
                );
            }
        }

        repository.delete(activity);
    }

    private DailyActivityResponse mapToResponse(DailyActivity activity) {
        // Convert tool IDs back to names
        List<String> toolNames = activity.getToolsUsedIds().stream()
                .map(id -> toolRepository.findById(id).map(Tool::getName).orElse("Unknown"))
                .collect(Collectors.toList());

        return DailyActivityResponse.builder()
                .id(activity.getId())
                .activityDate(activity.getActivityDate())
                .detailOfCase(activity.getDetailOfCase())
                .typeOfInformation(activity.getTypeOfInformation())
                .nameOfIO(activity.getNameOfIO())
                .toolsUsed(toolNames)
                .miscellaneousWork(activity.getMiscellaneousWorkList())
                .status(activity.getStatus().name())
                .remarks(activity.getRemarks())
                .createdAt(activity.getCreatedAt())
                .updatedAt(activity.getUpdatedAt())
                .build();
    }
}
