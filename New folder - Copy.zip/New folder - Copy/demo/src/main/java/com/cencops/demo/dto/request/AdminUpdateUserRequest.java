package com.cencops.demo.dto.request;

import com.cencops.demo.entity.User;
import lombok.Data;

@Data
public class AdminUpdateUserRequest {
    private String name;
    private String designation;
    private String username;
    private User.Status status;
    private User.Role role;
}
