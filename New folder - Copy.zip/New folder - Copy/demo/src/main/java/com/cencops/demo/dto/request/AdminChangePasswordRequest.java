package com.cencops.demo.dto.request;

import jakarta.validation.constraints.NotBlank;

public class AdminChangePasswordRequest {

    @NotBlank(message = "New password is required")
    private String newPassword;

    public String getNewPassword() {
        return newPassword;
    }
}

