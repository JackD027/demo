package com.cencops.demo.dto.request;

import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
public class DailyActivityRequest {
    private LocalDate activityDate;
    private String detailOfCase;
    private String typeOfInformation;
    private String nameOfIO;
    private List<String> toolsUsed;
    private List<String> miscellaneousWork;
    private String status;
    private String remarks;
}
