const API_BASE_URL = 'http://localhost:8080';

export function getAccessToken() {
  return localStorage.getItem('accessToken');
}

export function setTokens({ accessToken, refreshToken }) {
  if (accessToken) localStorage.setItem('accessToken', accessToken);
  if (refreshToken) localStorage.setItem('refreshToken', refreshToken);
}

export function clearTokens() {
  localStorage.removeItem('accessToken');
  localStorage.removeItem('refreshToken');
  localStorage.removeItem('userInfo'); // Recommended to clear this too
}

async function fetchWithAuth(url, options = {}, auth = true) {
  const headers = options.headers || {};

  if (auth) {
    const token = getAccessToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
  }

  const response = await fetch(API_BASE_URL + url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...headers,
    },
    credentials: 'include', 
  });

  if (!response.ok) {
    let errorMsg = `Error: ${response.status}`;
    try {
      const errData = await response.json();
      errorMsg = errData.message || JSON.stringify(errData);
    } catch {}
    throw new Error(errorMsg);
  }

  const contentType = response.headers.get('content-type') || '';
  if (contentType.includes('application/json')) {
    return response.json();
  } else {
    return response.text();
  }
}

// --- AUTH ---
export async function login(username, password) {
  return fetchWithAuth('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ username, password }),
  }, false);
}

export async function logout() {
  return fetchWithAuth('/auth/logout', {
    method: 'POST',
  });
}

// --- USER (SELF) ---
export async function getProfile() {
  return fetchWithAuth('/user/me');
}

export async function changePassword(oldPassword, newPassword) {
  return fetchWithAuth('/user/me/password', {
    method: 'PUT',
    body: JSON.stringify({ oldPassword, newPassword }),
  });
}

// --- ADMIN: USER MANAGEMENT ---

export async function getAllUsers() {
  return fetchWithAuth('/admin/users');
}

export async function registerUser(userData) {
  return fetchWithAuth('/admin/register', {
    method: 'POST',
    body: JSON.stringify(userData),
  });
}

export async function getUserById(userId) {
  return fetchWithAuth(`/admin/users/${userId}`);
}

export async function updateUser(userId, userData) {
  return fetchWithAuth(`/admin/users/${userId}`, {
    method: 'PUT',
    body: JSON.stringify(userData),
  });
}

export async function deleteUser(userId) {
  return fetchWithAuth(`/admin/users/${userId}`, {
    method: 'DELETE',
  });
}

/** * Change user status (ACTIVE/INACTIVE) 
 * @param {string} status - Enum value
 */
export async function updateUserStatus(userId, status) {
  return fetchWithAuth(`/admin/users/${userId}/status?status=${status}`, {
    method: 'PUT',
  });
}

/** Admin can reset anyone's password */
export async function adminChangeUserPassword(userId, newPassword) {
  return fetchWithAuth(`/admin/users/${userId}/password`, {
    method: 'PUT',
    body: JSON.stringify({ newPassword }),
  });
}

// --- SUPER ADMIN ---

/** * Only accessible by Super Admin to change user roles
 * @param {string} role - SUPER_ADMIN, ADMIN, MANAGER, ANALYST, USER
 */
export async function assignUserRole(userId, role) {
  return fetchWithAuth(`/super-admin/users/${userId}/role?role=${role}`, {
    method: 'PUT',
  });
}

// --- DAILY ACTIVITIES ---

export async function getMyActivities() {
  return fetchWithAuth('/daily-activities');
}

export async function createActivity(activityData) {
  return fetchWithAuth('/daily-activities', {
    method: 'POST',
    body: JSON.stringify(activityData),
  });
}

export async function updateActivity(id, activityData) {
  return fetchWithAuth(`/daily-activities/${id}`, {
    method: 'PUT',
    body: JSON.stringify(activityData),
  });
}

export async function deleteActivity(id) {
  return fetchWithAuth(`/daily-activities/${id}`, {
    method: 'DELETE',
  });
}

export async function getTools() {
  return fetchWithAuth('/daily-activities/tools');
}