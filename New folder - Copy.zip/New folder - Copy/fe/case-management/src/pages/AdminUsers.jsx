import React, { useEffect, useState, useRef } from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { Dropdown } from 'primereact/dropdown';
import { Toast } from 'primereact/toast';
import { Dialog } from 'primereact/dialog';
import { InputText } from 'primereact/inputtext';
import { Password } from 'primereact/password';
import { FilterMatchMode } from 'primereact/api';
import Swal from 'sweetalert2';

import { 
    getAllUsers, 
    updateUser, 
    registerUser 
} from '../api/api';

const AdminUsers = ({ user }) => {
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [displayRegisterModal, setDisplayRegisterModal] = useState(false);
    const [registerLoading, setRegisterLoading] = useState(false);
    const [globalFilterValue, setGlobalFilterValue] = useState('');
    const [filters, setFilters] = useState({
        global: { value: null, matchMode: FilterMatchMode.CONTAINS },
    });

    const [resetPasswordDialog, setResetPasswordDialog] = useState(false);
    const [selectedUser, setSelectedUser] = useState(null);
    const [newPassword, setNewPassword] = useState('');

const openResetDialog = (rowData) => {
    setSelectedUser(rowData);
    setNewPassword('');
    setResetPasswordDialog(true);
};

    const [newUserData, setNewUserData] = useState({
        name: '', designation: '', username: '', password: '', confirmPassword: '', role: 'ANALYST'
    });
    
    const toast = useRef(null);
    
    const roles = ['SUPER_ADMIN', 'ADMIN', 'ANALYST'];
    const assignableRoles = ['ADMIN', 'ANALYST'];

    useEffect(() => {
        fetchUsers();
    }, []);

    const fetchUsers = async () => {
        setLoading(true);
        try {
            const data = await getAllUsers();
            setUsers(data);
        } catch (err) {
            toast.current?.show({ severity: 'error', summary: 'Error', detail: err.message });
        } finally {
            setLoading(false);
        }
    };

    const handlePasswordReset = async () => {
        if (newPassword.length < 6) {
            Swal.fire('Error', 'Password must be at least 6 characters.', 'error');
            return;
        }
    
        try {
            await resetUserPassword(selectedUser.id, newPassword);
            
            setResetPasswordDialog(false);
            Swal.fire({
                title: 'Success!',
                text: `Password for ${selectedUser.name} has been updated.`,
                icon: 'success',
                confirmButtonColor: '#0d9488'
            });
        } catch (err) {
            Swal.fire('Failed', err.message, 'error');
        }
    };

    const handleStatusToggle = async (rowData) => {
        if (rowData.role === 'SUPER_ADMIN' || rowData.id === user.id) {
            Swal.fire('Restricted', 'Master accounts and your own account cannot be deactivated.', 'error');
            return;
        }

        const currentStatus = (rowData.status || 'ACTIVE').toUpperCase();
        const newStatus = currentStatus === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
        
        const result = await Swal.fire({
            title: 'Confirm Status Change',
            text: `Set ${rowData.name} to ${newStatus}?`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#0d9488', 
            confirmButtonText: `Yes, make ${newStatus}`
        });

        if (result.isConfirmed) {
            try {
                await updateUser(rowData.id, {
                    name: rowData.name,
                    designation: rowData.designation,
                    username: rowData.username,
                    role: rowData.role,
                    status: newStatus 
                });

                toast.current.show({ severity: 'success', summary: 'Updated', detail: `Status changed to ${newStatus}` });
                fetchUsers();
            } catch (err) {
                Swal.fire('Error', err.message, 'error');
            }
        }
    };

    const handleRoleChange = async (userId, newRole) => {
        const targetUser = users.find(u => u.id === userId);
        if (userId === user.id || targetUser.role === 'SUPER_ADMIN') {
            Swal.fire('Restricted', 'SUPER_ADMIN roles are protected.', 'error');
            return;
        }

        try {
            await updateUser(userId, { ...targetUser, role: newRole });
            toast.current.show({ severity: 'success', summary: 'Role Updated', detail: 'User role changed' });
            fetchUsers();
        } catch (err) {
            Swal.fire('Error', err.message, 'error');
        }
    };

    const handleRegisterUser = async () => {
        if (newUserData.password !== newUserData.confirmPassword) {
            Swal.fire('Error', 'Passwords do not match.', 'error');
            return;
        }
        setRegisterLoading(true);
        try {
            const { confirmPassword, ...payload } = newUserData;
            await registerUser(payload);
            setDisplayRegisterModal(false);
            setNewUserData({ name: '', designation: '', username: '', password: '', confirmPassword: '', role: 'ANALYST' });
            fetchUsers();
            Swal.fire('Success', 'Account created.', 'success');
        } catch (err) {
            Swal.fire('Error', err.message, 'error');
        } finally {
            setRegisterLoading(false);
        }
    };

    const onGlobalFilterChange = (e) => {
        const value = e.target.value;
        let _filters = { ...filters };
        _filters['global'].value = value;
        setFilters(_filters);
        setGlobalFilterValue(value);
    };

    const renderHeader = () => (
        <div className="flex flex-column md:flex-row md:justify-content-between md:align-items-center gap-2">
            <span className="p-input-icon-left w-full md:w-auto">
                <i className="pi pi-search" />
                <InputText value={globalFilterValue} onChange={onGlobalFilterChange} placeholder="Search names, usernames..." className="w-full" />
            </span>
            <Button label="Register Member" icon="pi pi-user-plus" className="p-button-teal" onClick={() => setDisplayRegisterModal(true)} />
        </div>
    );

    const statusBodyTemplate = (rowData) => {
        const isActive = (rowData.status || 'ACTIVE').toUpperCase() === 'ACTIVE';
        const isProtected = rowData.role === 'SUPER_ADMIN' || rowData.id === user.id;

        return (
            <Button 
                label={isActive ? "Active" : "Inactive"} 
                icon={isActive ? "pi pi-check" : "pi pi-times"}
                disabled={isProtected}
                className={`p-button-rounded p-button-sm ${isActive ? 'p-button-success' : 'p-button-danger'}`}
                onClick={() => handleStatusToggle(rowData)}
            />
        );
    };

    const roleBodyTemplate = (rowData) => {
        const isDisabled = user.role !== 'SUPER_ADMIN' || rowData.id === user.id || rowData.role === 'SUPER_ADMIN';
        return (
            <Dropdown 
                value={rowData.role} 
                options={rowData.role === 'SUPER_ADMIN' ? roles : assignableRoles} 
                onChange={(e) => handleRoleChange(rowData.id, e.value)}
                disabled={isDisabled}
                className="w-full"
            />
        );
    };

    return (
        <div className="p-4 md:p-6">
            <Toast ref={toast} />
            <div className="surface-card p-5 shadow-2 border-round-xl">
                <div className="mb-4">
                    <h1 className="text-2xl font-bold m-0 text-900">User Management</h1>
                    <p className="text-600">Permissions: {user.role}</p>
                </div>

                <DataTable 
                    value={users} loading={loading} paginator rows={10} 
                    header={renderHeader()} filters={filters} globalFilterFields={['name', 'username', 'designation']}
                    responsiveLayout="stack" breakpoint="960px"
                >
                    <Column field="name" header="Name" sortable />
                    <Column field="username" header="Username" sortable />
                    <Column field="designation" header="Designation" sortable />
                    <Column header="Role" body={roleBodyTemplate} />
                    <Column header="Account Status" body={statusBodyTemplate} />
                </DataTable>
            </div>

            <Dialog header="New Team Member" visible={displayRegisterModal} style={{ width: '400px' }} modal onHide={() => setDisplayRegisterModal(false)}
                footer={<div className="pt-3"><Button label="Cancel" onClick={() => setDisplayRegisterModal(false)} className="p-button-text" /><Button label="Register" onClick={handleRegisterUser} loading={registerLoading} className="p-button-teal" /></div>}>
                <div className="p-fluid">
                    <div className="field mb-3"><label className="font-bold">Full Name</label><InputText value={newUserData.name} onChange={(e) => setNewUserData({...newUserData, name: e.target.value})} /></div>
                    <div className="field mb-3"><label className="font-bold">Username</label><InputText value={newUserData.username} onChange={(e) => setNewUserData({...newUserData, username: e.target.value})} /></div>
                    <div className="field mb-3"><label className="font-bold">Designation</label><InputText value={newUserData.designation} onChange={(e) => setNewUserData({...newUserData, designation: e.target.value})} /></div>
                    <div className="field mb-3"><label className="font-bold">Role</label><Dropdown value={newUserData.role} options={assignableRoles} onChange={(e) => setNewUserData({...newUserData, role: e.target.value})} /></div>
                    <div className="field mb-3"><label className="font-bold">Password</label><Password value={newUserData.password} onChange={(e) => setNewUserData({...newUserData, password: e.target.value})} feedback={false} toggleMask /></div>
                    <div className="field mb-3"><label className="font-bold">Confirm Password</label><Password value={newUserData.confirmPassword} onChange={(e) => setNewUserData({...newUserData, confirmPassword: e.target.value})} feedback={false} toggleMask /></div>
                </div>
            </Dialog>
        </div>
    );
};

export default AdminUsers;