import React, { useEffect, useState } from 'react';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';
import { InputText } from 'primereact/inputtext';
import { Dropdown } from 'primereact/dropdown';
import { MultiSelect } from 'primereact/multiselect';
import { Calendar } from 'primereact/calendar';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Tag } from 'primereact/tag';
import Swal from 'sweetalert2';
import { useNavigate } from 'react-router-dom';

import {
  getMyActivities,
  createActivity,
  updateActivity,
  deleteActivity,
  getTools
} from '../api/api';

import '../styles/daily-activity.css';

const STATUS_OPTIONS = [
  { label: 'PENDING', value: 'PENDING' },
  { label: 'IN PROGRESS', value: 'IN_PROGRESS' },
  { label: 'COMPLETE', value: 'COMPLETE' }
];

const emptyForm = {
  activityDate: null,
  detailOfCase: '',
  typeOfInformation: '',
  nameOfIO: '',
  status: 'PENDING',
  toolsUsed: [],
  miscellaneousWork: '',
  remarks: ''
};

export default function DailyActivity() {
  const [activities, setActivities] = useState([]);
  const [tools, setTools] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [visible, setVisible] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [newToolName, setNewToolName] = useState('');
  const [expandedRows, setExpandedRows] = useState(null);
  const [user, setUser] = useState({ name: 'Admin User', role: 'Investigator' });

  const navigate = useNavigate();

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [acts, toolsData] = await Promise.all([getMyActivities(), getTools()]);
      setActivities(acts);
      setTools(toolsData.map(t => t.name));
    } catch (e) {
      if (e.message?.toLowerCase().includes('unauthorized')) navigate('/login');
      else Swal.fire('Error', 'Failed to load data', 'error');
    } finally {
      setLoading(false);
    }
  };

  const statusBodyTemplate = (row) => {
    const severityMap = { PENDING: 'warning', IN_PROGRESS: 'info', COMPLETE: 'success' };
    return <Tag value={row.status} severity={severityMap[row.status]} className="status-tag" />;
  };

  // Inside DailyActivity.jsx
const actionTemplate = (row) => (
    <div className="action-buttons-wrapper">
        <Button 
            icon="pi pi-pencil" 
            className="action-btn edit-btn" 
            tooltip="Edit Activity"
            tooltipOptions={{ position: 'top' }}
            onClick={() => openEdit(row)} 
        />
        <Button 
            icon="pi pi-trash" 
            className="action-btn delete-btn" 
            tooltip="Delete Activity"
            tooltipOptions={{ position: 'top' }}
            onClick={() => removeActivity(row.id)} 
        />
    </div>
);

  const openCreate = () => { setForm(emptyForm); setEditingId(null); setVisible(true); };

  const openEdit = (row) => {
    setForm({
      ...row,
      activityDate: new Date(row.activityDate),
      toolsUsed: row.toolsUsed || [],
      miscellaneousWork: Array.isArray(row.miscellaneousWork) ? row.miscellaneousWork.join(', ') : row.miscellaneousWork
    });
    setEditingId(row.id);
    setVisible(true);
  };

  const saveActivity = async () => {
    try {
      const miscWorkStr = Array.isArray(form.miscellaneousWork) ? form.miscellaneousWork.join(', ') : form.miscellaneousWork || '';
      const payload = {
        ...form,
        activityDate: form.activityDate.toISOString().split('T')[0],
        miscellaneousWork: miscWorkStr.split(',').map(v => v.trim()).filter(Boolean),
        toolsUsed: [...new Set(form.toolsUsed)]
      };

      if (editingId) await updateActivity(editingId, payload);
      else await createActivity(payload);

      Swal.fire({ icon: 'success', title: 'Saved Successfuly', showConfirmButton: false, timer: 1500 });
      setVisible(false);
      loadData();
    } catch (error) {
      Swal.fire('Error', 'Failed to save', 'error');
    }
  };

  const addNewTool = () => {
    if (newToolName.trim() && !tools.includes(newToolName.trim())) {
      setTools([...tools, newToolName.trim()]);
      setForm({ ...form, toolsUsed: [...form.toolsUsed, newToolName.trim()] });
      setNewToolName('');
    }
  };

  const removeActivity = async (id) => {
    const res = await Swal.fire({ title: 'Delete Activity?', icon: 'warning', showCancelButton: true, confirmButtonColor: '#0d9488' });
    if (res.isConfirmed) { await deleteActivity(id); loadData(); }
  };

  return (
    <div className="daily-page">
      <div className="daily-container">
        <div className="page-header">
          <div className="title-area">
            <h1>Daily Activities</h1>
            <p className="text-muted">Manage investigative cases and tool logs</p>
          </div>
          <Button label="Add Activity" icon="pi pi-plus" className="teal-btn" onClick={openCreate} />
        </div>

        <div className="table-card shadow-1">
          <DataTable
            value={activities} loading={loading} paginator rows={10}
            className="p-datatable-sm custom-teal-table" dataKey="id"
            expandedRows={expandedRows} onRowToggle={(e) => setExpandedRows(e.data)}
            rowExpansionTemplate={(row) => (
              <div className="expansion-panel">
                <div className="grid">
                  <div className="col-12 md:col-6">
                    <p><strong>Name of IO:</strong> {row.nameOfIO || '-'}</p>
                    <p><strong>Misc Work:</strong> {Array.isArray(row.miscellaneousWork) ? row.miscellaneousWork.join(', ') : row.miscellaneousWork || '-'}</p>
                  </div>
                  <div className="col-12 md:col-6">
                    <p><strong>Remarks:</strong> {row.remarks || '-'}</p>
                  </div>
                </div>
              </div>
            )}
          >
            <Column expander style={{ width: '3rem' }} />
            <Column header="Date" body={r => new Date(r.activityDate).toLocaleDateString()} sortable />
            <Column field="detailOfCase" header="Detail of Case" sortable />
            <Column field="typeOfInformation" header="Type of Info" sortable />
            <Column field="status" header="Status" body={statusBodyTemplate} sortable />
            <Column header="Tools" body={r => (
              <div className="flex flex-wrap gap-1">
                {r.toolsUsed?.map(t => <span key={t} className="tool-chip">{t}</span>)}
              </div>
            )} />
            <Column body={actionTemplate} header="Actions" />
          </DataTable>
        </div>
      </div>

      <Dialog header={editingId ? 'Edit Activity' : 'Create Activity'} visible={visible} onHide={() => setVisible(false)} className="teal-dialog" modal>
        <div className="form-grid">
          <div className="field">
            <label>Activity Date</label>
            <Calendar value={form.activityDate} onChange={e => setForm({ ...form, activityDate: e.value })} showIcon className="w-full" />
          </div>
          <div className="field">
            <label>Status</label>
            <Dropdown value={form.status} options={STATUS_OPTIONS} onChange={e => setForm({ ...form, status: e.value })} className="w-full" />
          </div>
          <div className="field">
            <label>Detail of Case</label>
            <InputText value={form.detailOfCase} onChange={e => setForm({ ...form, detailOfCase: e.target.value })} className="w-full" />
          </div>
          <div className="field">
            <label>Type of Information</label>
            <InputText value={form.typeOfInformation} onChange={e => setForm({ ...form, typeOfInformation: e.target.value })} className="w-full" />
          </div>
          <div className="field">
            <label>Name of IO</label>
            <InputText value={form.nameOfIO} onChange={e => setForm({ ...form, nameOfIO: e.target.value })} className="w-full" />
          </div>
          <div className="field">
            <label>Misc Work (comma separated)</label>
            <InputText value={form.miscellaneousWork} onChange={e => setForm({ ...form, miscellaneousWork: e.target.value })} className="w-full" />
          </div>
          <div className="field full-width">
            <label>Tools Used</label>
            <MultiSelect
              value={form.toolsUsed}
              options={tools}
              display="chip"
              filter
              onChange={e => setForm({ ...form, toolsUsed: e.value })}
              className="w-full custom-multiselect" // Added a custom class
              placeholder="Select Tools"
              panelFooterTemplate={() => (
                <div className="flex p-2 gap-2 border-top-1 border-200">
                  <InputText
                    value={newToolName}
                    onChange={e => setNewToolName(e.target.value)}
                    placeholder="New tool..."
                    className="p-inputtext-sm flex-1"
                  />
                  <Button icon="pi pi-plus" onClick={addNewTool} className="p-button-sm teal-btn" />
                </div>
              )}
            />
          </div>
          <div className="field full-width">
            <label>Remarks</label>
            <InputText value={form.remarks} onChange={e => setForm({ ...form, remarks: e.target.value })} className="w-full" />
          </div>
          <div className="field full-width mt-2">
            <Button label={editingId ? 'Update' : 'Create'} className="teal-btn w-full py-3" onClick={saveActivity} />
          </div>
        </div>
      </Dialog>
    </div>
  );
}