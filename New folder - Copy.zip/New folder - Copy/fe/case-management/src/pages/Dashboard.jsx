import React from 'react';
import '../styles/dashboard.css';

const Dashboard = ({ user }) => {
  // Logic: Only Admin and Super Admin can view
  const isAuthorized = user?.role === 'ADMIN' || user?.role === 'SUPER_ADMIN';

  console.log(user);
  

  if (!isAuthorized) {
    return (
      <div className="flex align-items-center justify-content-center min-h-screen bg-slate-50">
        <div className="surface-card p-6 shadow-2 border-round-xl text-center" style={{ maxWidth: '450px' }}>
          <div className="flex justify-content-center mb-4">
            <div className="bg-red-100 border-circle flex align-items-center justify-content-center" style={{ width: '80px', height: '80px' }}>
              <i className="pi pi-lock text-red-600 text-4xl"></i>
            </div>
          </div>
          <h2 className="text-900 font-bold mb-3">Access Restricted</h2>
          <p className="text-600 mb-5 line-height-3">
            Sorry, <strong>{user?.name}</strong>. The Dashboard is reserved for Administrators. 
            Analysts and standard users do not have permission to view this data.
          </p>
          <button 
            className="p-button p-button-outlined p-button-danger w-full"
            onClick={() => window.history.back()}
          >
            Return to Previous Page
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="dashboard-wrapper p-4 md:p-6">
      <div className="grid">
        {/* Welcome Section */}
        <div className="col-12 mb-4">
          <div className="flex flex-column md:flex-row md:align-items-center justify-content-between gap-3">
            <div>
              <h1 className="text-3xl font-bold text-900 m-0">Admin Dashboard</h1>
              <p className="text-600 mt-2">Overview of system activities and user logs.</p>
            </div>
            <div className="flex gap-2">
              <button className="p-button p-button-outlined p-button-secondary">
                <i className="pi pi-download mr-2"></i> Export Report
              </button>
              <button className="p-button">
                <i className="pi pi-plus mr-2"></i> New Entry
              </button>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="col-12 md:col-6 lg:col-3">
          <div className="stat-card p-4 shadow-1 bg-white border-round-xl border-left-3 border-teal-500">
            <span className="block text-500 font-medium mb-3">Active Cases</span>
            <div className="flex align-items-center justify-content-between">
              <span className="text-900 font-bold text-2xl">152</span>
              <span className="bg-teal-100 text-teal-700 px-2 py-1 border-round-md text-sm font-bold">+12%</span>
            </div>
          </div>
        </div>

        <div className="col-12 md:col-6 lg:col-3">
          <div className="stat-card p-4 shadow-1 bg-white border-round-xl border-left-3 border-blue-500">
            <span className="block text-500 font-medium mb-3">Total Users</span>
            <div className="flex align-items-center justify-content-between">
              <span className="text-900 font-bold text-2xl">1,042</span>
              <i className="pi pi-users text-blue-500 text-2xl"></i>
            </div>
          </div>
        </div>

        <div className="col-12 md:col-6 lg:col-3">
          <div className="stat-card p-4 shadow-1 bg-white border-round-xl border-left-3 border-orange-500">
            <span className="block text-500 font-medium mb-3">Pending Tasks</span>
            <div className="flex align-items-center justify-content-between">
              <span className="text-900 font-bold text-2xl">38</span>
              <i className="pi pi-clock text-orange-500 text-2xl"></i>
            </div>
          </div>
        </div>

        <div className="col-12 md:col-6 lg:col-3">
          <div className="stat-card p-4 shadow-1 bg-white border-round-xl border-left-3 border-purple-500">
            <span className="block text-500 font-medium mb-3">System Health</span>
            <div className="flex align-items-center justify-content-between">
              <span className="text-900 font-bold text-2xl">99.9%</span>
              <i className="pi pi-check-circle text-purple-500 text-2xl"></i>
            </div>
          </div>
        </div>

        {/* Visualization Placeholder */}
        <div className="col-12 mt-4">
          <div className="surface-card p-5 shadow-2 border-round-xl">
            <div className="flex align-items-center justify-content-between mb-5">
              <h3 className="m-0 text-xl font-bold text-800">Activity Analytics</h3>
              <div className="text-teal-600 cursor-pointer font-medium hover:underline">View Detailed Logs</div>
            </div>
            <div 
              className="flex align-items-center justify-content-center border-2 border-dashed border-300 border-round-lg"
              style={{ minHeight: '350px', backgroundColor: '#fafafa' }}
            >
              <div className="text-center">
                <i className="pi pi-chart-bar text-400 text-6xl mb-3"></i>
                <p className="text-500">Analytical charts and user trends will be visualized here.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;