import React, { useRef } from 'react';
import { Menubar } from 'primereact/menubar';
import { Avatar } from 'primereact/avatar';
import { TieredMenu } from 'primereact/tieredmenu';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';
import { clearTokens } from '../api/api';
import '../styles/header.css';

const Header = ({ user, showProfile = true }) => {
    const navigate = useNavigate();
    const menu = useRef(null);

    const handleLogout = () => {
        clearTokens();
        Swal.fire({
            icon: 'success',
            title: 'Logged Out',
            timer: 1500,
            showConfirmButton: false,
        });
        navigate('/login', { replace: true });
    };

    // Menu items now navigate to the separate Profile page
    const items = [
        { 
            label: 'My Profile', 
            icon: 'pi pi-user', 
            command: () => navigate('/profile') 
        },
        { 
            label: 'Logout', 
            icon: 'pi pi-sign-out', 
            command: handleLogout 
        },
    ];

    const start = (
        <div className="flex align-items-center">
            <img
                src="/src/assets/logo.png" 
                alt="Logo"
                className="logo-img"
                onClick={() => navigate('/dashboard')}
                style={{ cursor: 'pointer' }}
            />
        </div>
    );

    const end = showProfile ? (
        <div className="flex align-items-center">
            <Avatar
                label={user?.name ? user.name[0].toUpperCase() : 'U'}
                shape="circle"
                className="avatar"
                onClick={(e) => menu.current.toggle(e)}
            />
            <TieredMenu model={items} popup ref={menu} />
        </div>
    ) : null;

    return (
        <div className="header-wrapper">
            <Menubar start={start} end={end} className="header-menubar" />
        </div>
    );
};

export default Header;