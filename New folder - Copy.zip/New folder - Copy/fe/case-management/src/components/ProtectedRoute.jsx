import React from 'react';
import { Navigate } from 'react-router-dom';
import { getAccessToken } from '../api/api';

const ProtectedRoute = ({ children, requiredRoles }) => {
  const token = localStorage.getItem('accessToken');
  const userInfo = JSON.parse(localStorage.getItem('userInfo'));

  if (!token) return <Navigate to="/login" replace />;

  if (requiredRoles) {
    const hasRole = requiredRoles.includes(userInfo?.role);
    
    if (!hasRole) {
      console.warn("Access denied. User role:", userInfo?.role);
      return <Navigate to="/daily-activities" replace />;
    }
  }

  return children;
};

export default ProtectedRoute;